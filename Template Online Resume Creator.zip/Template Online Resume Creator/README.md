# Resume generator
Web based editor to create Resume in a customizable template with the facility to save the file in .pdf formate.  


###### Technologies: HTML, CSS, JavaScript


#### Features
- Resume content can be edited just like a normal document editor (cut,copy,undo etc).
- Entire sections can be added, reordered, removed just by cut,copy,pasting method.
- Section visibility can be toggled while retaining the content.
- Options provided in the left panel to modify the template and formatting.
- Sub-points can be added with various bullet styles and adjustable indentation.
- Script provided to merge multiple pages and compress the PDF.


**Note** : Use Google Chrome





